namespace CrmApi.Models;

/// <summary>
/// Representa um tenant (espaço de trabalho) no modelo multi-tenant (M2M).
/// Todas as demais entidades pertencem a um Workspace.
/// </summary>
public class Workspace
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<Company> Companies { get; set; } = new List<Company>();
    public ICollection<Contact> Contacts { get; set; } = new List<Contact>();
}
