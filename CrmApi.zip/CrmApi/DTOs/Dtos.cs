namespace CrmApi.DTOs;

public record WorkspaceCreateDto(string Name);
public record WorkspaceDto(Guid Id, string Name, DateTime CreatedAt);

public record CompanyCreateDto(string Name, string? Industry);
public record CompanyDto(Guid Id, Guid WorkspaceId, string Name, string? Industry, DateTime CreatedAt);

public record ContactCreateDto(string Name, string? Email, string? Phone, Guid? CompanyId);
public record ContactDto(Guid Id, Guid WorkspaceId, Guid? CompanyId, string Name, string? Email, string? Phone, DateTime CreatedAt);
