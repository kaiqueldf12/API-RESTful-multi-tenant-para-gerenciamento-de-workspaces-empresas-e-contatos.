using CrmApi.Data;
using CrmApi.DTOs;
using CrmApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CrmApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class WorkspacesController : ControllerBase
{
    private readonly CrmDbContext _db;
    public WorkspacesController(CrmDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<WorkspaceDto>>> GetAll()
    {
        var items = await _db.Workspaces
            .Select(w => new WorkspaceDto(w.Id, w.Name, w.CreatedAt))
            .ToListAsync();
        return Ok(items);
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<WorkspaceDto>> GetById(Guid id)
    {
        var w = await _db.Workspaces.FindAsync(id);
        if (w is null) return NotFound();
        return Ok(new WorkspaceDto(w.Id, w.Name, w.CreatedAt));
    }

    [HttpPost]
    public async Task<ActionResult<WorkspaceDto>> Create(WorkspaceCreateDto dto)
    {
        var workspace = new Workspace { Name = dto.Name };
        _db.Workspaces.Add(workspace);
        await _db.SaveChangesAsync();

        var result = new WorkspaceDto(workspace.Id, workspace.Name, workspace.CreatedAt);
        return CreatedAtAction(nameof(GetById), new { id = workspace.Id }, result);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var w = await _db.Workspaces.FindAsync(id);
        if (w is null) return NotFound();

        _db.Workspaces.Remove(w);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
