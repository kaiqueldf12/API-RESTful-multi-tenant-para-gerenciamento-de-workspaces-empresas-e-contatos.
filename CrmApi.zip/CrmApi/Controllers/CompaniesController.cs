using CrmApi.Data;
using CrmApi.DTOs;
using CrmApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CrmApi.Controllers;

// Rotas aninhadas no workspace para reforçar o isolamento multi-tenant:
// /api/workspaces/{workspaceId}/companies
[ApiController]
[Route("api/workspaces/{workspaceId:guid}/[controller]")]
public class CompaniesController : ControllerBase
{
    private readonly CrmDbContext _db;
    public CompaniesController(CrmDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<CompanyDto>>> GetAll(Guid workspaceId)
    {
        var items = await _db.Companies
            .Where(c => c.WorkspaceId == workspaceId)
            .Select(c => new CompanyDto(c.Id, c.WorkspaceId, c.Name, c.Industry, c.CreatedAt))
            .ToListAsync();
        return Ok(items);
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<CompanyDto>> GetById(Guid workspaceId, Guid id)
    {
        var c = await _db.Companies.FirstOrDefaultAsync(x => x.Id == id && x.WorkspaceId == workspaceId);
        if (c is null) return NotFound();
        return Ok(new CompanyDto(c.Id, c.WorkspaceId, c.Name, c.Industry, c.CreatedAt));
    }

    [HttpPost]
    public async Task<ActionResult<CompanyDto>> Create(Guid workspaceId, CompanyCreateDto dto)
    {
        var workspaceExists = await _db.Workspaces.AnyAsync(w => w.Id == workspaceId);
        if (!workspaceExists) return NotFound($"Workspace {workspaceId} não encontrado.");

        var company = new Company
        {
            WorkspaceId = workspaceId,
            Name = dto.Name,
            Industry = dto.Industry
        };
        _db.Companies.Add(company);
        await _db.SaveChangesAsync();

        var result = new CompanyDto(company.Id, company.WorkspaceId, company.Name, company.Industry, company.CreatedAt);
        return CreatedAtAction(nameof(GetById), new { workspaceId, id = company.Id }, result);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid workspaceId, Guid id, CompanyCreateDto dto)
    {
        var company = await _db.Companies.FirstOrDefaultAsync(x => x.Id == id && x.WorkspaceId == workspaceId);
        if (company is null) return NotFound();

        company.Name = dto.Name;
        company.Industry = dto.Industry;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid workspaceId, Guid id)
    {
        var company = await _db.Companies.FirstOrDefaultAsync(x => x.Id == id && x.WorkspaceId == workspaceId);
        if (company is null) return NotFound();

        _db.Companies.Remove(company);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
