using CrmApi.Data;
using CrmApi.DTOs;
using CrmApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CrmApi.Controllers;

[ApiController]
[Route("api/workspaces/{workspaceId:guid}/[controller]")]
public class ContactsController : ControllerBase
{
    private readonly CrmDbContext _db;
    public ContactsController(CrmDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ContactDto>>> GetAll(Guid workspaceId, [FromQuery] Guid? companyId)
    {
        var query = _db.Contacts.Where(c => c.WorkspaceId == workspaceId);
        if (companyId is not null)
            query = query.Where(c => c.CompanyId == companyId);

        var items = await query
            .Select(c => new ContactDto(c.Id, c.WorkspaceId, c.CompanyId, c.Name, c.Email, c.Phone, c.CreatedAt))
            .ToListAsync();
        return Ok(items);
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<ContactDto>> GetById(Guid workspaceId, Guid id)
    {
        var c = await _db.Contacts.FirstOrDefaultAsync(x => x.Id == id && x.WorkspaceId == workspaceId);
        if (c is null) return NotFound();
        return Ok(new ContactDto(c.Id, c.WorkspaceId, c.CompanyId, c.Name, c.Email, c.Phone, c.CreatedAt));
    }

    [HttpPost]
    public async Task<ActionResult<ContactDto>> Create(Guid workspaceId, ContactCreateDto dto)
    {
        var workspaceExists = await _db.Workspaces.AnyAsync(w => w.Id == workspaceId);
        if (!workspaceExists) return NotFound($"Workspace {workspaceId} não encontrado.");

        if (dto.CompanyId is not null)
        {
            var companyBelongs = await _db.Companies.AnyAsync(c => c.Id == dto.CompanyId && c.WorkspaceId == workspaceId);
            if (!companyBelongs) return BadRequest("A empresa informada não pertence a este workspace.");
        }

        var contact = new Contact
        {
            WorkspaceId = workspaceId,
            CompanyId = dto.CompanyId,
            Name = dto.Name,
            Email = dto.Email,
            Phone = dto.Phone
        };
        _db.Contacts.Add(contact);
        await _db.SaveChangesAsync();

        var result = new ContactDto(contact.Id, contact.WorkspaceId, contact.CompanyId, contact.Name, contact.Email, contact.Phone, contact.CreatedAt);
        return CreatedAtAction(nameof(GetById), new { workspaceId, id = contact.Id }, result);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid workspaceId, Guid id, ContactCreateDto dto)
    {
        var contact = await _db.Contacts.FirstOrDefaultAsync(x => x.Id == id && x.WorkspaceId == workspaceId);
        if (contact is null) return NotFound();

        contact.Name = dto.Name;
        contact.Email = dto.Email;
        contact.Phone = dto.Phone;
        contact.CompanyId = dto.CompanyId;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid workspaceId, Guid id)
    {
        var contact = await _db.Contacts.FirstOrDefaultAsync(x => x.Id == id && x.WorkspaceId == workspaceId);
        if (contact is null) return NotFound();

        _db.Contacts.Remove(contact);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
