using CrmApi.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Controllers
builder.Services.AddControllers();

// Swagger / OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "CRM M2M API",
        Version = "v1",
        Description = "API RESTful multi-tenant para o CRM (workspaces, empresas e contatos)."
    });
});

// EF Core - InMemory para começar rápido.
// Troque para UseSqlServer/UseNpgsql apontando para sua connection string em produção.
builder.Services.AddDbContext<CrmDbContext>(options =>
    options.UseInMemoryDatabase("CrmDb"));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
